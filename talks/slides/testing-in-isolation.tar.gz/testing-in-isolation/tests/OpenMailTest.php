<?php

class OpenMailTest extends PHPUnit_Framework_TestCase
{
    public function testShowAMailSubjectTextAndTheSenderAddress()
    {
        // $mail = new OpenMail('Urgent', 'Lorem ipsum...', $stubAddress));
        $this->markTestIncomplete();
    }
}
