<?php

class PlainTextAddressTest extends PHPUnit_Framework_TestCase
{
    public function testShowAnAddressWithNoLink()
    {
        // $address = new PlainTextAddress('isaac@example.com');
        $this->markTestIncomplete();
    }
}
