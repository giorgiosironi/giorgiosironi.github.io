<?php
interface MailAddress
{
    public function __toString();
}
