<?php

interface Messages
{
    public function getNext();
}
